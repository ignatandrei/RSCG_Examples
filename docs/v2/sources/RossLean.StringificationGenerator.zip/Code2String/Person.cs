﻿using RossLean.StringificationGenerator.Core;

namespace Code2String;
[GenerateConstructionCode]
public record Person(string firstName, string lastName)
{
    
}
