﻿var strVersion = RSCG_Version.BuildInformation.AssemblyVersion;
System.Console.WriteLine(strVersion);
