﻿using BitsDemo;

var z = new zlib_header(0x78, 0x9C);
Console.WriteLine( z.FLEVEL );
Console.WriteLine(z.CM);