﻿using Biwen.AutoClassGen.Attributes;

namespace FromInterface;

[AutoGen("Person", "FromInterface")]
public interface IPerson2: IPerson
{

}
