﻿using ToStringData;

Console.WriteLine("Hello, World!");
Person person = new ();
person.FirstName = "Andrei";
person.LastName = "Ignat";
Console.WriteLine(person.ToString());
