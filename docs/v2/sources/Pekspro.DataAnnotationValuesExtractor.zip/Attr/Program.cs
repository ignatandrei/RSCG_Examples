﻿// See https://aka.ms/new-console-template for more information
using Attr;

Console.WriteLine(Person.Annotations.Age.Minimum);
Console.WriteLine(Person.Annotations.FirstName.MinimumLength);
Console.WriteLine(Person.Annotations.FirstName.MaximumLength);
