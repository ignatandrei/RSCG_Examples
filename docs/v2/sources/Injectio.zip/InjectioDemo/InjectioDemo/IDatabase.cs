﻿namespace InjectioDemo
{
    internal interface IDatabase
    {
        public void Open();
    }
}