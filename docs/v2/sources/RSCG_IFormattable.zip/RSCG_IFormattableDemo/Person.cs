﻿
namespace RSCG_IFormattableDemo;
[RSCG_IFormattableCommon.AddIFormattable]
internal partial class Person
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
}
