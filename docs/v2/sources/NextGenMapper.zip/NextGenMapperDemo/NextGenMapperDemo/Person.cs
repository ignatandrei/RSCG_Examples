﻿
namespace NextGenMapperDemo;

internal class Person
{
    public int ID { get; set; } 
    public string? Name { get; set; }
    public string? Country_Name { get; set; }
    public string? Country_CountryCode { get; set; }
}


