﻿namespace InjectDemo
{
    internal interface IDatabase
    {
        public void Open();
    }
}