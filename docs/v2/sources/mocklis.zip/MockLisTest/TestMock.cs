﻿namespace TestClock;

[MocklisClass]
public partial class TestMock : IMyClock
{

}