global using Microsoft.VisualStudio.TestTools.UnitTesting;
global using MockTest;
global using Mocklis.Core;