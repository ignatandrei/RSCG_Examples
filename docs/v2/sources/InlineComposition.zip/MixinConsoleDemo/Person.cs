﻿
using InlineCompositionAttributes;

namespace MixinConsoleDemo;
[InlineBase]
internal class Person
{
    
    public string Name { get; set; } = string.Empty;
        public int Age { get; set; }
    
}
