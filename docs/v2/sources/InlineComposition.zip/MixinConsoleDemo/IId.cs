﻿using InlineCompositionAttributes;

namespace MixinConsoleDemo;
[InlineBase]
internal class IId
{
    public int Id { get; set; }
}
