﻿using PMart.Enumeration.Generator.Attributes;

namespace DemoPMart;
[Enumeration]
public partial class PersonType
{
    private static readonly string ValueForEmployee = "Employee";
    private static readonly string ValueForManager = "Manager";


}
