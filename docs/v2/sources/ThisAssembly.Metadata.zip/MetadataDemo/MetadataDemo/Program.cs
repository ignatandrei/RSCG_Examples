﻿[assembly: System.Reflection.AssemblyMetadataAttribute("Name", "Test")]

Console.WriteLine(ThisAssembly.Metadata.Name);
Console.WriteLine(ThisAssembly.Metadata.MyName);
