﻿
namespace EnumDemo;
public enum CarTypes 
{
    None,
    Dacia ,
    Tesla ,
    BMW ,
    Mercedes ,
}
