﻿namespace MockData;

public interface IMyClock
{
    public DateTime GetNow();
    public DateTime GetUtcNow();
}