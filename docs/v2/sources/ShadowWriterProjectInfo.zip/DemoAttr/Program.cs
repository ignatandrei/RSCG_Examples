﻿// Access project information anywhere in your code 
using ShadowWriter;
Console.WriteLine($"Project Name: {TheProject.Name}");
Console.WriteLine($"Project Version: {TheProject.Version}");
Console.WriteLine($"Project Build Date: {TheProject.BuildTimeUtc}");