﻿using MvvmGen;
namespace PropChangeDemo;

[ViewModel]
partial class Person
{
    [Property] private string _FirstName;

    
}
