global using Microsoft.VisualStudio.TestTools.UnitTesting;
global using Imposter.Abstractions;

[assembly: GenerateImposter(typeof(MockData.IMyClock))]

