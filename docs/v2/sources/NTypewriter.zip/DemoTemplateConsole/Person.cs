﻿
namespace DemoTemplateConsole;
public class PersonModel
{
    public int Name { get; set; }
}
