﻿
using Nino.Core;

namespace SerializerDemo;
[NinoType]
public partial class Person
{
    public int Age;

    public string Name = string.Empty;

    
}

