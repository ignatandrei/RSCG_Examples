﻿using EnumClassDemo;
Console.WriteLine(Colors.None.GetName());
Console.WriteLine(ColorsExtensions.GetContent()[Colors.None]);