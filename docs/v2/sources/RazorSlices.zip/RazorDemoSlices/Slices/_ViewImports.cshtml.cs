using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemoSlices.Slices
{
    public class _ViewImportsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
