﻿global using Mediator;
global using Microsoft.Extensions.DependencyInjection;