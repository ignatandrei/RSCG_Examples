﻿Console.WriteLine(ResXDemo.GenResourcesModel.MyName);
Console.WriteLine(ResXDemo.GenResources.MyName);

