﻿using M31FluentAPIDemo;

Console.WriteLine("Hello, World!");
var p =CreatePerson
    //the order does matter
    .Named("Andrei","Ignat")
    .HasDOB(null);
