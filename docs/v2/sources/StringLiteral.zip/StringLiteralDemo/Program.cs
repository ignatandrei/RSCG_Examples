﻿using StringLiteralDemo;
using System.Text;

Console.WriteLine(Encoding.UTF8.GetString(LiteralConstants.MyName()));
