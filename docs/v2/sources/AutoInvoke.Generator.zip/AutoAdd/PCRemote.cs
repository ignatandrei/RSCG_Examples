﻿
namespace AutoAdd;
internal class PCRemote : IRemoteCommand
{
    public void Execute()
    {
        Console.WriteLine("start PC");
    }
}
