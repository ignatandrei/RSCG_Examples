﻿
namespace AutoAdd;
internal class TVRemote : IRemoteCommand
{
    public void Execute()
    {
        Console.WriteLine("start TV");
    }
}
