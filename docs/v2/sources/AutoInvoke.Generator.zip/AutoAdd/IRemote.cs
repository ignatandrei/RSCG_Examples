﻿
namespace AutoAdd;
internal interface IRemoteCommand
{
        void Execute();
}

