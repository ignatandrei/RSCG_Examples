﻿namespace Person;

public class PersonData
{
    public string Name { get; set; }
    public int Age { get; set; }
}


