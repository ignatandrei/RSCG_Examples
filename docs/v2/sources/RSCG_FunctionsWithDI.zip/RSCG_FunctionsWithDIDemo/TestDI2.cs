﻿namespace RSCG_FunctionsWithDIDemo;

public class TestDI2
{
    public int x;
}
