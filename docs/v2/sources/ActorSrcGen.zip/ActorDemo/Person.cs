﻿
namespace ActorDemo;
public class Person
{
    public string Name { get; set; }
}
