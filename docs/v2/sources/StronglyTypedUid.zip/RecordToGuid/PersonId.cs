﻿
using StronglyTypedUid;

namespace RecordToGuid;
[StronglyTypedUid]
public readonly partial record struct PersonId
{
}
