﻿using RecordToGuid;

PersonId personId = PersonId.Empty;
Console.WriteLine(personId);
personId = PersonId.NewPersonId();
Console.WriteLine(personId);
