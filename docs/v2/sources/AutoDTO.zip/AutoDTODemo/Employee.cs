﻿namespace AutoDTODemo;

public class Employee
{
    public int ID { get; set; }
    public string Name { get; set; }
    public Department Department { get; set; }

}
