﻿Console.WriteLine(BenjaminAbt.AssemblyMetadata.AssemblyMetadataInfo.BuildInfo.BuildDateYear);
