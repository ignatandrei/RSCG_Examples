﻿global using Microsoft.Extensions.DependencyInjection;
global using DeeDee.Models;
