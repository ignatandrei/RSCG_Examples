﻿using QueryStringGenerator;
namespace DemoQuery;
[QueryString]
internal class Person
{
    public string FirstName { get; set; }=string.Empty;
    public int Age {  get; set; }
    public string LastName { get; set; } = string.Empty;

}
