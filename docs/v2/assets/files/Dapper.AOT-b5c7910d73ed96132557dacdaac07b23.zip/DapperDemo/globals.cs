﻿global using Dapper;
global using Microsoft.Data.SqlClient;
global using DapperDemo;


[module: DapperAot]