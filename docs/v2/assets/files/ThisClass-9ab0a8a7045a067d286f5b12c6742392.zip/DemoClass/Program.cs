﻿using DemoClass;

Person person = new Person();
person.Name = "Andrei Ignat";
Console.WriteLine(person.Name);
Console.WriteLine(Person.ThisClass.FullName);
