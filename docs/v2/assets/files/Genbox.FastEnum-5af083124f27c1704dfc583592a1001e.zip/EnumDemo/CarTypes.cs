﻿
namespace EnumDemo;
[Genbox.FastEnum.FastEnum]
public enum CarTypes 
{
    None,
    Dacia ,
    Tesla ,
    BMW ,
    Mercedes ,
}
