﻿
namespace EnumDemo;
public enum RequiredCarTypes
{
    None,
    Dacia ,
    Tesla ,
    BMW ,
    Mercedes ,
}
