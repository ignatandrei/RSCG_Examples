﻿Console.WriteLine(ThisAssembly.Resources.Content.mytext.Text);
