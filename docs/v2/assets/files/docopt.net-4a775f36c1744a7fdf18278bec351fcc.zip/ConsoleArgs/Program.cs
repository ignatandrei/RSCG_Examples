﻿//Console.WriteLine(ConsoleArgs.ProgramArguments.Help);
Console.WriteLine(ConsoleArgs.ProgramArguments.Usage);