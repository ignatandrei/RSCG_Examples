﻿// See https://aka.ms/new-console-template for more information
using Lombok.NETDemo;

Console.WriteLine("Hello, World!");
Person p = new();
p.FirstName = "Andrei";
p.LastName="Ignat";
Console.WriteLine(p.ToString());