﻿using DemoMixin;

Person person = new Person { Name = "Andrei Ignat" };
person.LogName();