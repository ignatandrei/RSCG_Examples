﻿// See https://aka.ms/new-console-template for more information
System.Console.WriteLine("Hello, World!");
