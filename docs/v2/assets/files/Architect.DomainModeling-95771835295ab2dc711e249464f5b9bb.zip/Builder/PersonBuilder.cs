﻿using Architect.DomainModeling;

namespace Builder;

[DummyBuilder<Person>]
public partial class PersonBuilder
{
}