﻿namespace GetTypesForInterface;
public class Teacher:IPerson
{
    public string Name { get; set; } = "";
}

