﻿
namespace GetTypesForInterface;
internal interface IPerson
{
    public string Name { get; set; }
}
