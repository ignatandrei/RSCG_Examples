﻿
namespace GetTypesForInterface;
public class Student : IPerson
{
    public string Name { get; set; } = "";
}
    
