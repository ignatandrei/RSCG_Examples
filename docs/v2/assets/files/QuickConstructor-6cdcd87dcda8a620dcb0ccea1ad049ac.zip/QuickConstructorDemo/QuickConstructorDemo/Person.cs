﻿using QuickConstructor.Attributes;

namespace QuickConstructorDemo;

[QuickConstructor]
internal partial class Person
{
    private readonly string FirstName;
    private readonly string? LastName;

    
}
