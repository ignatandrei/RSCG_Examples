﻿using GedaqDemoConsole;

var data = new GetData();

