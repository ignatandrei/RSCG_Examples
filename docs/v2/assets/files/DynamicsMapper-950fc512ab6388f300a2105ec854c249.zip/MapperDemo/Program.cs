﻿using NextGenMapperDemo;
var pm = new PersonMapper();
Console.WriteLine(pm.Entityname);