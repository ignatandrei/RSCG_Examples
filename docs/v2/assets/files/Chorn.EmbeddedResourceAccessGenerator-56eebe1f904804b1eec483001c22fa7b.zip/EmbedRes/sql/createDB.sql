create database Andrei;
GO;
use Andrei;
GO;
