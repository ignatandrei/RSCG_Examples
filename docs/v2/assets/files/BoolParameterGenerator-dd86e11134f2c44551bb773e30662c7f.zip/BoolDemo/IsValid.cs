﻿
using PrimS.BoolParameterGenerator;

namespace BoolDemo;
[GenerateBinaryEnum("TrueValue", "FalseValue", GenerateAssertionExtensions =false)]
//[GenerateBoolEnum("TrueValue", "FalseValue", GenerateAssertionExtensions = false)]
public partial class IsValid
{
}
