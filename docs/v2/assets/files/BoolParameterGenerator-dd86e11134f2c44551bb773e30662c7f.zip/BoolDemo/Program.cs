﻿using BoolDemo;

Console.WriteLine(IsValid.TrueValue);
