﻿using QuickConstructorDemo;

var p = new Person("Andrei", "Ignat");