﻿global using Microsoft.Extensions.Logging;
global using Microsoft.Extensions.DependencyInjection;
global using RSCG_DecoratorTestConsole;
