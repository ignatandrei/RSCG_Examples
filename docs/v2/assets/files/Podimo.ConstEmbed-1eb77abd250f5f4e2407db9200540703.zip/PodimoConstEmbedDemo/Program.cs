﻿Console.WriteLine(MyAppNamespace.SQL.createDB);
