﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine($"Version: {DemoGit.GitInfo.Branch}");
Console.WriteLine($"Version: {DemoGit.GitInfo.CommitDate}");
