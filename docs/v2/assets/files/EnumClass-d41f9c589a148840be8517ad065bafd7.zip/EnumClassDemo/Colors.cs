﻿using EnumClass.Attributes;

namespace EnumClassDemo;
[EnumClass]
public enum Colors
{
    None=0,
    Red,
    Green,
    Blue,
}
