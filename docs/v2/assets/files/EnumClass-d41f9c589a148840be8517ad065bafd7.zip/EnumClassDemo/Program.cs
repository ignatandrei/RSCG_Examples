﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Console.WriteLine(EnumClassDemo.EnumClass.Colors.None.ToString());
Console.WriteLine(EnumClassDemo.EnumClass.Colors.Red.TestMe());
