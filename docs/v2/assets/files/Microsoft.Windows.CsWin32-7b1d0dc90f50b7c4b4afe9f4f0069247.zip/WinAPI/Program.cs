﻿
Console.WriteLine("Hello, World!" + Windows.Win32.PInvoke.GetTickCount());
