﻿global using MemoryPack;
global using MemoryPackDemo;