﻿namespace RSCG_FunctionsWithDIDemo;

public class TestDI1
{
    public int x;
}
