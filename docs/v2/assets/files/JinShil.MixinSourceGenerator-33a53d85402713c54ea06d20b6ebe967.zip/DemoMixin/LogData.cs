﻿
namespace DemoMixin;
internal class LogData
{
    public void Log(string data) => Console.WriteLine(data);
}
