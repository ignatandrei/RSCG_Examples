﻿using GobieDemo;

Person p = new();
p.Name = "Andrei ";
//this comes from Gobie template
p.Id = 1;
