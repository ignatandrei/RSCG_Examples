﻿using Gobie;
namespace GobieDemo;

[ClassGenAddId()]
partial class Person
{
    public string? Name { get; set; }

}
