﻿// Access project information anywhere in your code 
Console.WriteLine($"Project Name: {AssemblyVersionInfo.Assembly.NAME}");
Console.WriteLine($"Project Version: {AssemblyVersionInfo.Assembly.VERSION}");
;