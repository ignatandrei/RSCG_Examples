﻿namespace TestSignalRCommon;

public class MessageData 
{
    public string User { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;

}
