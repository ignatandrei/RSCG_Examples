﻿namespace AutoRegisterInjectDemo
{
    internal interface IDatabase
    {
        void Open();
    }
}