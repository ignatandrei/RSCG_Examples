﻿namespace AutoRegisterInjectDemo;

[RegisterSingleton]
internal class DatabaseCon
{
    public string? Connection { get; set; }
}

