﻿using EnumClassDemo;
Console.WriteLine(Colors.None.ToStringFast());
Console.WriteLine(Colors.None.ToEnumMemberValue());