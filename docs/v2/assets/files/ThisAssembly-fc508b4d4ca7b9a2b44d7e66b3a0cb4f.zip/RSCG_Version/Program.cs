﻿var strVersion = ThisAssembly.Info.Version;
System.Console.WriteLine(strVersion);
