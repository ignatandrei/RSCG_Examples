﻿namespace DemoValidatorObj;

[OptionsValidator]
public partial class ValidatorForMyApp
    : IValidateOptions<MyAppOptions>
{
}

//public class SecondModelNoNamespace
//{
//    [Required]
//    [MinLength(5)]
//    public string P4 { get; set; } = string.Empty;
//}


//[OptionsValidator]
//public partial class SecondValidatorNoNamespace
//    : IValidateOptions<SecondModelNoNamespace>
//{
//}


