﻿using Class2String;
using Seekatar.OptionToStringGenerator;
var p = new Person();
p.FirstName = "Andrei";
p.LastName = "Ignat";
p.Age = 50;
Console.WriteLine(p.OptionsToString());    