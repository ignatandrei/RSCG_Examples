﻿using Demo;
//https://learn.microsoft.com/en-us/dotnet/standard/base-types/regular-expression-source-generators
//https://devblogs.microsoft.com/dotnet/regular-expression-improvements-in-dotnet-7/
var x = "Abc";
Console.WriteLine(DemoRegex.EvaluateText(x));