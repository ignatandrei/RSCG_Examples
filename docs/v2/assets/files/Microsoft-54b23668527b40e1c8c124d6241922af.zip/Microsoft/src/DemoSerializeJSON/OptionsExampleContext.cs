﻿using System.Text.Json.Serialization;

namespace JsonSerializerOptionsExample;
//Generator:OptionsExampleContext.WeatherForecast.g.cs
[JsonSerializable(typeof(WeatherForecast))]
internal partial class OptionsExampleContext : JsonSerializerContext
{
}
