﻿
using GedaqDemoConsole.Example1;

await ExampleRun.Run();