﻿using DependencyModules.Runtime.Attributes;

namespace InjectionDemo.Common;

[DependencyModule]
public partial class CommonModule { }