﻿namespace InjectionDemo.Common
{
    public interface IDatabase
    {
        public void Open();
    }
}