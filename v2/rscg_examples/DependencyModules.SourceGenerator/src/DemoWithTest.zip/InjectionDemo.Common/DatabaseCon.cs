﻿
using DependencyModules.Runtime.Attributes;

namespace InjectionDemo.Common;

public interface IDatabaseCon {
    string? Connection { get; }

    void Open();
}


[SingletonService]
public class DatabaseCon:IDatabase
{
    public string? Connection { get; set; }
    public void Open()
    {
        Console.WriteLine("open from database con" );
    }
}

