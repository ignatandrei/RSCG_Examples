using DependencyModules.Testing.Attributes;
using InjectDemo;
using InjectionDemo.Common;
using NSubstitute;
using Xunit;

namespace InjectionDemo.Tests;

public class ServiceClassTests {
    [ModuleTest]
    public void ServiceClassTest(ServiceClass serviceClass) {
        Assert.NotNull(serviceClass);
    }

    [ModuleTest]
    public void MockTest(ServiceClass serviceClass, [Mock] IDatabase mockDatabase) {
        Assert.NotNull(serviceClass);
        
        serviceClass.Open();

        mockDatabase.Received().Open();
    }
}