using DependencyModules.Testing.NSubstitute;

[assembly: MyModule.Attribute]
[assembly: NSubstituteSupport]