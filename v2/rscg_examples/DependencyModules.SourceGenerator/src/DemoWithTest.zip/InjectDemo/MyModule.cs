﻿using DependencyModules.Runtime.Attributes;
using InjectionDemo.Common;

[DependencyModule]
[CommonModule.Attribute]
public partial class MyModule 
{ 

}