using DependencyModules.Runtime.Attributes;
using InjectionDemo.Common;

namespace InjectDemo;

[SingletonService]
public class ServiceClass(IDatabase database) {
    public void Open() {
        database.Open();
    }
}