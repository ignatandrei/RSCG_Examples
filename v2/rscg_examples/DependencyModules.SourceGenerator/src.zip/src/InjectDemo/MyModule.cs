﻿using DependencyModules.Runtime.Attributes;

[DependencyModule]
public partial class MyModule 
{ 

}