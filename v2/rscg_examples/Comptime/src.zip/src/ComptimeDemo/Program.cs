﻿
Console.WriteLine("Hello, World!");

var sum2 = ComptimeDemo.Math.SumList(new[] { 10, 20, 30 });
Console.WriteLine($"Sum: {sum2}");
var x=ComptimeDemo.Math.Factorial(5);
Console.WriteLine($"Factorial: {x}");

