﻿global using Refit;
global using RefitDemo;
