﻿using Strings.ResourceGenerator.Examples.Resources;
Console.WriteLine("Hello, World!");
Console.WriteLine(Countries.Goodbye("World"));

Console.WriteLine(Countries.IT.Goodbye("Mondo"));