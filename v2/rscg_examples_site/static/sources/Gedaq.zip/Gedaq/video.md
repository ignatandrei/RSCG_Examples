{
    "step_1_exec":"clipchamp.exe launch",
    "step_2_text": "Welcome to Roslyn Examples - the introduction is automatically generated",
    "step_3_text":"If you want to see more examples , see  [List Of RSCG] https://ignatandrei.github.io/RSCG_Examples/v2/docs/List-of-RSCG",
    "step_4_browser":"https://ignatandrei.github.io/RSCG_Examples/v2/docs/List-of-RSCG",
    "step_5_text": "My name is Andrei Ignat and I am deeply fond of Roslyn Source Code Generator. ",

"step_6_text": "Today I will present Gedaq  that is good for Generating code from attribute query .",
"step_7_browser":"https://www.nuget.org/packages/Gedaq/",
"step_8_text": "You can download the code from https://ignatandrei.github.io/RSCG_Examples/v2/docs/Gedaq)",
"step_9_browser":"https://ignatandrei.github.io/RSCG_Examples/v2/docs/Gedaq",
"step_10_text":" Here is the code ",
"step_11_exec":"explorer.exe /select,C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\GedaqDemoConsole.csproj",
"step_12_text": "So , let's start the project ",
"step_13_exec": "C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\GedaqDemoConsole.csproj",

"step_14_text": "You put the  [Gedaq](https://www.nuget.org/packages/Gedaq/) into the csproj ",

"step_15_exec": "C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe /edit C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\GedaqDemoConsole.csproj",

"step_16_text": "I have used the Gedaq in those files",


        "step_17_exec":"C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe /edit C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\PersonRepository.cs",
    
        "step_18_exec":"C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe /edit C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\Person.cs",
    
        "step_19_exec":"C:\\Program Files\\Microsoft Visual Studio\\2022\\Community\\Common7\\IDE\\devenv.exe /edit C:\\gth\\RSCG_Examples\\v2\\rscg_examples\\Gedaq\\src\\GedaqDemoConsole\\Program.cs",
    
"step_20_hide": "hide"


}