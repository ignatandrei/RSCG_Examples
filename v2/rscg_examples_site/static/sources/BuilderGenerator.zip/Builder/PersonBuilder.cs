﻿namespace Builder;

[BuilderGenerator.BuilderFor(typeof(Person))]
public partial class PersonBuilder
{
}