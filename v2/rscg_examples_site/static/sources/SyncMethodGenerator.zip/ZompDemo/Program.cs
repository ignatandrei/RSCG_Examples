﻿// See https://aka.ms/new-console-template for more information
using Zomp.SyncMethodGeneratorDemo;

Console.WriteLine("Hello, World!");
Writer.Haha("a.txt", "Andrei Ignat");
Writer.Write("a.txt", "andrei ignat");