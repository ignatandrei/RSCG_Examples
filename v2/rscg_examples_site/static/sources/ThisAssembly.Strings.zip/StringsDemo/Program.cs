﻿Console.WriteLine(ThisAssembly.Strings.PersonName("Andrei Ignat"));
