namespace ArgPars;

enum OutputFormat
{
    None,
    Json,
    Xml,
    Csv
}
