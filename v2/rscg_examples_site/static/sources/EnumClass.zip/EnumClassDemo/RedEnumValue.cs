﻿namespace EnumClassDemo.EnumClass;
public abstract partial class Colors
{
    public partial class RedEnumValue
    {
        public string? TestMe()
        {
            return ToString();
        }
    }
}