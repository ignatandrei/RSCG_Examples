﻿using ProtoBuf;

namespace ProtobufSourceGeneratorDemo;

[ProtoContract]
public partial class Person
{
    [ProtoMember(1)]
    public string? Name { get; set; }
}
