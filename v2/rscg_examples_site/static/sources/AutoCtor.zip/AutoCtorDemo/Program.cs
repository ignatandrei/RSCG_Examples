﻿// See https://aka.ms/new-console-template for more information
using AutoCtorDemo;

Console.WriteLine("Hello, World!");

var p = new Person("Andrei", "Ignat");
