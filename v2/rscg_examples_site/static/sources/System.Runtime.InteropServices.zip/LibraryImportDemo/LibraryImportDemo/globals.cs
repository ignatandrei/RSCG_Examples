﻿global using static System.Console;
global using static DemoImport;
global using System.Runtime.InteropServices;
