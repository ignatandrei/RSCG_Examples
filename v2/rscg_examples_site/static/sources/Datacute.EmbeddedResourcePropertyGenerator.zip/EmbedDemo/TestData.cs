﻿using Datacute.EmbeddedResourcePropertyGenerator;
namespace EmbedDemo;
[EmbeddedResourceProperties(".txt", "TestData")]
public static partial class TestData;
