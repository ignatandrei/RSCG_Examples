﻿// See https://aka.ms/new-console-template for more information
using EmbedDemo;

Console.WriteLine("Hello, World!");

var data= TestData.Countries;

Console.WriteLine(data);