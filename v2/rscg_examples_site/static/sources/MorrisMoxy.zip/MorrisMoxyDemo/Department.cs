﻿
namespace MorrisMoxyDemo;
[IDName]
partial class Department
{
}
