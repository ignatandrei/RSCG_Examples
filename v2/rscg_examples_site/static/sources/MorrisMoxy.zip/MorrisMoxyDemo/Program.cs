﻿// See https://aka.ms/new-console-template for more information
using MorrisMoxyDemo;
var e = new Employee();
e.Name = "Andrei";
var d = new Department();
d.Name = "IT";
Console.WriteLine(e.ID);