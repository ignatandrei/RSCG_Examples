﻿

namespace MorrisMoxyDemo;
[IDName]
partial class Employee
{
}
