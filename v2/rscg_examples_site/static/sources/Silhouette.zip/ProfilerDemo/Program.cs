﻿// See https://andrewlock.net/creating-a-dotnet-profiler-using-csharp-with-silhouette/
Console.WriteLine("Please read https://andrewlock.net/creating-a-dotnet-profiler-using-csharp-with-silhouette/");
