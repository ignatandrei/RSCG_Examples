﻿//https://devblogs.microsoft.com/dotnet/testing-your-native-aot-dotnet-apps/
namespace MyImportantClass;

public class Class1
{
    public int Add(int v1, int v2)
    {
        return v1 + v2;
    }
}
