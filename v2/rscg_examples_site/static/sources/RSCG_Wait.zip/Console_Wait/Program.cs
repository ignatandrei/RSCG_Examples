﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine(RSCG_Wait.MyGeneratedCode.DateStart);
Console.WriteLine(RSCG_Wait.MyGeneratedCode.SecondsToWait);
Console.WriteLine(RSCG_Wait.MyGeneratedCode.DateEnd);
Console.WriteLine(RSCG_Wait.OptionsFromBuild.build_property_projectdir);
Console.WriteLine(RSCG_Wait.OptionsFromBuild.build_property_rootnamespace);
Console.WriteLine(RSCG_Wait.OptionsFromBuild.build_property__supportedplatformlist );
