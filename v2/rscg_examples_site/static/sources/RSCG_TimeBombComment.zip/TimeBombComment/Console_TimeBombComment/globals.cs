﻿global using Console_TimeBombComment;
global using System;
