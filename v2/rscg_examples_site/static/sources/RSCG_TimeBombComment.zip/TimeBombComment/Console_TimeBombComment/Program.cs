﻿var d = new TestClass();
Console.Write(d.DataObsolete());
Console.Write(d.CommentsWithErrors());
Console.WriteLine("See the TB comment above ? ");
