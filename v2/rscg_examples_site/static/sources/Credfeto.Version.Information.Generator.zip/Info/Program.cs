﻿Console.WriteLine(Info.VersionInformation.Version);
Console.WriteLine(Info.VersionInformation.Product);
