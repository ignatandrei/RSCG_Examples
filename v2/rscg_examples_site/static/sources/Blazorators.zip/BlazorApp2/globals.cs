﻿global using Microsoft.JSInterop;
global using BlazorApp2;