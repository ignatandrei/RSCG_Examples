﻿global using Breezy;
global using Microsoft.Data.SqlClient;
global using BreezyDemo;
